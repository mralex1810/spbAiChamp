package spb_ai_champ.myClasses;

public enum Behaviour {

    ANTI_PUSH,
    BUILD
}
