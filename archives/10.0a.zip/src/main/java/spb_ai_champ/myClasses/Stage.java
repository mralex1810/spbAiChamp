package spb_ai_champ.myClasses;

public enum Stage {
    FIRST(1),
    SECOND(2),
    THIRD(3);
    public int tag;
    Stage(int tag) {
        this.tag = tag;
    }
}
